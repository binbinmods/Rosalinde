# 1.2.0

Significant update to art and cards

# 1.1.0

Fixed Curing Heal not working well in the forge/with level ups

Fixed Elemental Roar damage.

# 1.0.0

Initial release.