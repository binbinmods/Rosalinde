# 1.3.2

Updated hitsound and enabled config for shifting the gameobject.

# 1.3.1

Decks can now be saved

# 1.3.0

Fixed crash in Obelisk Challenge Mode

Further card updates

# 1.2.1

Nerfed base speed to 13 from 14.

# 1.2.0

- Nerfed LEVEL UP HP to +8 per extra level
- Nerfed "Elemental Roar" damage by ~20
- Improved INNATE Trait grammar wording
- Added (purple) World Tree Leaf acquirable
- Nerfed Animist-Energy Level Trait to "Dispel 2" from "Dispel 3"
- Reworked all artwork for character in game
- Modified "Mod Icon Image" for Thunderstore use as desired replacement
- Fixed various possible card bugs surrounding "Elemental Roar" (I hope lol)
- Improved / edited various character lore flavor text
- Edited some Texts Level Up Traits Text (Grammar only)
- Improved various sounds and effects for cards 

# 1.1.0

Fixed Curing Heal not working well in the forge/with level ups

Fixed Elemental Roar damage.

# 1.0.0

Initial release.